<?php

/**
 * @license LGPLv3, http://opensource.org/licenses/LGPL-3.0
 * @copyright Aimeos (aimeos.org), 2017-2018
 */

$enc = $this->encoder();

?>
<div id="related" class="row item-related tab-pane fade" role="tabpanel" aria-labelledby="related">
	<?= $this->get( 'relatedBody' ); ?>
</div>
